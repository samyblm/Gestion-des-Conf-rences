import React from 'react';
import './App.css';
import MyNavbar from './components/Navbar/navbar';
import Stest from './components/carousels/slidertest';
import News from './components/carousels/news';
import Articles from './components/carousels/articles';
import Conferences from './components/carousels/conferencs'
import Types from './components/carousels/types'
import Footer from './components/footer/footer'


function App() {
  return (
    <div className="App">
      <MyNavbar />
      <Stest />
      <News />
      <Articles />
      <Conferences />
      <Types />
      <Footer />
      
    </div>
  );
}

export default App;
