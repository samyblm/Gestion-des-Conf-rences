import React from 'react'
import Row from 'react-bootstrap/Row'
import './slider.css'


function Articles() {
    return (
        <div className="articles">>
         <h2 className="comp-title"> Articles</h2>
            <Row xs={1} md={2} className="g-6">
                {Array.from({ length: 6 }).map((_, idx) => (
                    <div>
                        <div className="art-card">
                            <div className="article-img">
                 
                                {/* <img src={article}  /> */}
                            </div>
                            <div className="text-card">
                                <div className="article-info">
                                    <h3>title</h3>
                                    <p>place,location</p>
                                    <p>author</p>
                                </div>
                                <div className="article-text">
                                    <p>Lorem ipsum dolor sit amet, consectetur adip
                                        commodo felis auctor lacus luctus posuere.
                                        nisl ut porta gravida, sapien enim suscipit an,
                                        justo. Aenean rutrum lorem in eleifend vestibulum.</p>

                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </Row>


        </div>
    )
}

export default Articles
