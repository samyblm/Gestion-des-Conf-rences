
import React, { useRef, useState } from "react";

import { Swiper, SwiperSlide } from "swiper/react";
import './slider.css'
import Button from 'react-bootstrap/Button'

import "swiper/swiper.min.css";
import "swiper/components/effect-coverflow/effect-coverflow.min.css"
import "swiper/components/pagination/pagination.min.css"




import SwiperCore, {
    EffectCoverflow, Pagination
} from 'swiper/core';


SwiperCore.use([EffectCoverflow, Pagination]);


export default function Types() {



    return (
        <div className="swiperr swiper-types">
             <h2 className="comp-title"> Types </h2>
        <>
            <Swiper effect={'coverflow'} initialSlide={1} loop={true} grabCursor={true} centeredSlides={true} slidesPerView={6} coverflowEffect={{
                "rotate": 0,
                "stretch": 0,
                "depth": 0,
                "modifier": 1,
                "slideShadows": false
            }} pagination={false} edgeSwipeDetection={true} className="mySwiper">

               




                <SwiperSlide>
                    <span>
                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                    <div className="slide-type">
                        <h1>slide1</h1>
                    </div>
                    </span>
                </SwiperSlide>
                <SwiperSlide>
                <span>
                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                    <div className="slide-type">
                        <h1>slide1</h1>
                    </div>
                    </span>
                </SwiperSlide>
                <SwiperSlide>
                <span>
                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                    <div className="slide-type">
                        <h1>slide1</h1>
                    </div>
                    </span>
                </SwiperSlide>
                <SwiperSlide>
                <span>
                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                    <div className="slide-type">
                        <h1>slide1</h1>
                    </div>
                    </span>
                </SwiperSlide>
                <SwiperSlide>
                <span>
                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                    <div className="slide-type">
                        <h1>slide1</h1>
                    </div>
                    </span>
                </SwiperSlide>
                <SwiperSlide>
                <span>
                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                    <div className="slide-type">
                        <h1>slide1</h1>
                    </div>
                    </span>
                </SwiperSlide>
                <SwiperSlide>
                <span>
                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                    <div className="slide-type">
                        <h1>slide1</h1>
                    </div>
                    </span>
                </SwiperSlide>
                <SwiperSlide>
                <span>
                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                    <div className="slide-type">
                        <h1>slide1</h1>
                    </div>
                    </span>
                </SwiperSlide>
       
            </Swiper>
        </>
        <div className="rejoindre-nous">
          <Button variant="secondary">rejoindre-nous</Button>
        </div>
        </div>
    )
}