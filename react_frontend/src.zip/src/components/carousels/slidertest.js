import React from 'react';
import './slider.css'
import "react-responsive-carousel/lib/styles/carousel.min.css"; // requires a loader
import { Carousel } from 'react-responsive-carousel';
import img1 from '../../images/img1.png'
import img2 from '../../images/img2.png'
import img3 from '../../images/img3.png'
import front1 from '../../images/front1.png'
import front2 from '../../images/front2.png'
import front3 from '../../images/front3.png'
import card1 from '../../images/card1.png'
import card2 from '../../images/card2.png'
import card3 from '../../images/card3.png'


export default function Stest() {
  return (

    <div className="slide-image">
      <img src={front1} width={'100%'} className="front-image1" />
      <img src={front2} width={'100%'} className="front-image2" />
      <img src={front3} width={'100%'} className="filtre" />

      <Carousel autoPlay infiniteLoop height={800} showThumbs={false} transitionTime={2000} >

        <div >
          <img src={img1} />
          <p className="legend">Legend 1</p>
        </div>
        <div>
          <img src={img2} />
          <p className="legend">Legend 2</p>
        </div>
        <div>
          <img src={img3} />
          <p className="legend"  >Legend 3</p>
        </div>
      </Carousel>

      <container className="cards-container card-group">

        <h2 className="cards-title">Comment ca marche</h2>

        <div class="card-group">
          <div class="card">
            <img class="card-img-top" src={card1} alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Apprendre</h5>
              <p class="card-text">lire, apprendre et assister
                à des conférences et des
                articles scientifiques.</p>

            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src={card2} alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Idée</h5>
              <p class="card-text">créer une bonne idée
                ou préparer votre article
                scientifique pour
                faire une conférence</p>

            </div>
          </div>
          <div class="card">
            <img class="card-img-top" src={card3} alt="Card image cap" />
            <div class="card-body">
              <h5 class="card-title">Organisé</h5>
              <p class="card-text">Co-op et organiser votre
                propre evenement
                conferencielle</p>

            </div>
          </div>
        </div>
      </container>

    </div>
  )
};

