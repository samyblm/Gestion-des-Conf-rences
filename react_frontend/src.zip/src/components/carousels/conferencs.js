import React from 'react'
import Row from 'react-bootstrap/Row'
import './slider.css'
import conf from '../../images/conf.png'
import Button from 'react-bootstrap/Button'

function Conferences() {
    return (
        <div className="conf-container">

            <div className="conferences">>
             <h2 className="comp-title"> Conferences</h2>
                <Row xs={1} md={3} className="g-6">
                    {Array.from({ length: 3 }).map((_, idx) => (
                        <div>
                            <div className="conf-card">
                                <div className="conf-img">
                                  <img src={conf}   />                        
                                </div>
                                <div className="text-card">
                                    <div className="conf-info">
                                        <h3>title</h3>
                                        <p>sujet</p>
                                        <p>place,location</p>
                                    </div>
                                    <div className="conf-text">
                                        <p>Lorem ipsum dolor sit amet, consectetur adip
                                            commodo felis auctor lacus luctus posuere.
                                            nisl ut porta gravida, sapien enim suscipit an,
                                            justo. Aenean rutrum lorem in eleifend vestibulum.</p>

                                            <Button variant="secondary">decouvrir</Button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    ))}
                </Row>

                </div>

            </div>
            )
}

            export default Conferences
