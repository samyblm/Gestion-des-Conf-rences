
import React, { useRef, useState } from "react";

import { Swiper, SwiperSlide } from "swiper/react";
import './slider.css'


import "swiper/swiper.min.css";
import "swiper/components/effect-coverflow/effect-coverflow.min.css"
import "swiper/components/pagination/pagination.min.css"




import SwiperCore, {
    EffectCoverflow, Pagination
} from 'swiper/core';


SwiperCore.use([EffectCoverflow, Pagination]);


export default function News() {



    return (
        <div className="swiperr swiper-news">
            <h2 className="comp-title"> News </h2>
        <>
            <Swiper effect={'coverflow'} initialSlide={1} loop={false} grabCursor={true} centeredSlides={true} slidesPerView={3} coverflowEffect={{
                "rotate": 0,
                "stretch": 0,
                "depth": 100,
                "modifier": 1,
                "slideShadows": false
            }} pagination={false} edgeSwipeDetection={true} className="mySwiper">


                <SwiperSlide className="smll">
                    <img src="https://swiperjs.com/demos/images/nature-1.jpg" />
                    <div className="slide-text2">
                        <h1>slide1</h1>
                    </div>
                </SwiperSlide>
                <SwiperSlide className="smll">
                    <img src="https://swiperjs.com/demos/images/nature-2.jpg" />
                    <div className="slide-text2">
                        <h1>slide1</h1>
                    </div>
                </SwiperSlide>
                <SwiperSlide className="smll">
                    <img src="https://swiperjs.com/demos/images/nature-3.jpg" />
                    <div className="slide-text2">
                        <h1>slide1</h1>
                    </div>
                </SwiperSlide>
       
            </Swiper>
        </>
        </div>
    )
}